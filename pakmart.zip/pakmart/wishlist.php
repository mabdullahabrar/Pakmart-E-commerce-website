<?php
include "header.php";
?>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3 class="title">My Wishlist</h3>
                </div>
            </div>
            <div id="wishlist_data">
                <!-- Wishlist items will be loaded here dynamically -->
            </div>
        </div>
    </div>
</div>

<?php
include "newslettter.php";
include "footer.php";
?>